function aloe(){
    if(document.getElementById("rosewater").innerHTML === "Aloe + Rosewater"){
       document.getElementById("rosewater").innerHTML= "N3,500"
     }else {
        document.getElementById("rosewater").innerHTML= "Aloe + Rosewater"
     }
}
function mask(){
    if(document.getElementById("facemask").innerHTML === "Vitamin C Face Mask"){
        document.getElementById("facemask").innerHTML= "N1,500"
      }else {
         document.getElementById("facemask").innerHTML= "Vitamin C Face Mask"
      }
}
function eos(){
    if(document.getElementById("lipbalm").innerHTML === "EOS Lipbalm"){
        document.getElementById("lipbalm").innerHTML= "N3,200"
      }else {
         document.getElementById("lipbalm").innerHTML= "EOS Lipbalm"
      }
    }
function serum(){
    if(document.getElementById("goodskinclub").innerHTML === "Good Skin Club Serum"){
        document.getElementById("goodskinclub").innerHTML= "N10,500"
      }else {
         document.getElementById("goodskinclub").innerHTML= "Good Skin Club Serum"
      }
}
function set(){
    if(document.getElementById("detanglingset").innerHTML === "Detangling Set"){
        document.getElementById("detanglingset").innerHTML= "N15,500"
      }else {
         document.getElementById("detanglingset").innerHTML= "Detangling Set"
      }
}
function balm(){
    if(document.getElementById("watermelonlipbalm").innerHTML === "Fresh Sugar Watermelon Lipbalm"){
        document.getElementById("watermelonlipbalm").innerHTML= "N2,500"
      }else {
         document.getElementById("watermelonlipbalm").innerHTML= "Fresh Sugar Watermelon Lipbalm"
      }
}
function lotion(){
    if(document.getElementById("bodylotion").innerHTML === "Necessaire Body Lotion"){
        document.getElementById("bodylotion").innerHTML= "N6,800"
      }else {
         document.getElementById("bodylotion").innerHTML= "Necessaire Body Lotion"
      }
}
function oil(){
    if(document.getElementById("hairoil").innerHTML === "Ziza Hair Growth Oil"){
        document.getElementById("hairoil").innerHTML= "N3,000"
      }else {
         document.getElementById("hairoil").innerHTML= "Ziza Hair Growth Oil"
      }
}
function spf(){
    if(document.getElementById("sunscreen").innerHTML === "Jade Mineral Sunscreen"){
        document.getElementById("sunscreen").innerHTML= "N10,000"
      }else {
         document.getElementById("sunscreen").innerHTML= "Jade Mineral Sunscreen"
      }
}
function scrub(){
    if(document.getElementById("bodyscrub").innerHTML === "Soft Body Scrub"){
        document.getElementById("bodyscrub").innerHTML= "N4,000"
      }else {
         document.getElementById("bodyscrub").innerHTML= "Soft Body Scrub"
      }
}
function hair(){
    if(document.getElementById("shampoo").innerHTML === "Mara Cruz Natural Shampoo"){
        document.getElementById("shampoo").innerHTML= "N3,500"
      }else {
         document.getElementById("shampoo").innerHTML= "Mara Cruz Natural Shampoo"
      }
}
function lip(){
    if(document.getElementById("lipstick").innerHTML === "Innisfree Lipstick"){
        document.getElementById("lipstick").innerHTML= "N1,500"
      }else {
         document.getElementById("lipstick").innerHTML= "Innisfree Lipstick"
      }
}