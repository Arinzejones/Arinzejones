
window.alert("Get ready to be blown away!!!");
function price1(){
    if(document.getElementById("Motor1").innerHTML === "Affordable prices"){
        document.getElementById("Motor1").innerHTML = "$3,000,000.00 (Three million dollars only)"
    } else {
        document.getElementById("Motor1").innerHTML = "Affordable prices"
    }
}

function soup(){
    if(document.getElementById("Motor2").innerHTML === "Beauty at first sight"){
        document.getElementById("Motor2").innerHTML = "N3,500.00 ($2,000,000.00 (two million dollars only)"
    } else{
        document.getElementById("Motor2").innerHTML = "Beauty at first sight"
    }
}

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Six Million)"
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."
    }
}

function soup(){
    if(document.getElementById("Motor4").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Motor4").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Motor4").innerHTML = "2. Ofe Nsala and Yellow Eba."
    }
}