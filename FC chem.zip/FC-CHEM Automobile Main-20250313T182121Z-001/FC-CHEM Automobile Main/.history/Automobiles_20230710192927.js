if(document.getElementById("Motor").innerHTML === "images/img1.png"){
    document.getElementById("Motor").innerHTML = "N3,000,000.00 (Three million Naira only)";
} else {
    document.getElementById("Motor").innerHTML = "images/img1.png"};

    function rice(){
        if(document.getElementById("Ofada").innerHTML === "images/img1.png"){
            document.getElementById("Ofada").innerHTML = "N3,000,000.00 (Three million Naira only)";
        } else {
            document.getElementById("Ofada").innerHTML = ""};
    }
    