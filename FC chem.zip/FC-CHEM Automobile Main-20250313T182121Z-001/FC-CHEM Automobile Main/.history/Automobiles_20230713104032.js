function img1(){
        if(document.getElementById("Motor").innerHTML === "Af"){
            document.getElementById("Motor").innerHTML = "N3,000,000.00 (Three million Naira only)";
        } else {
            document.getElementById("Motor").innerHTML = "images/img1.png"};
    }
    