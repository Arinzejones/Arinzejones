
window.alert("Get ready to be blown away!!!");
function price1(){
    if(document.getElementById("Motor1").innerHTML === "Affordable prices"){
        document.getElementById("Motor1").innerHTML = "$3,000,000.00 (Three Million dollars only)"
    } else {
        document.getElementById("Motor1").innerHTML = "Affordable prices"
    }
}

function soup(){
    if(document.getElementById("Motor2").innerHTML === "Beauty at first sight"){
        document.getElementById("Motor2").innerHTML = "$2,000,000.00 (Two Million dollars only)"
    } else{
        document.getElementById("Motor2").innerHTML = "Beauty at first sight"
    }
}

function price3(){
    if(document.getElementById("Motor3").innerHTML === "Check this out"){
        document.getElementById("Motor3").innerHTML = "$6,000,000.00 (Six Million dollars only)"
    } else{
        document.getElementById("Motor3").innerHTML = "Check this out"
    }
}

function price3(){
    if(document.getElementById("Motor4").innerHTML === "Need for speed"){
        document.getElementById("Motor4").innerHTML = "$11,000,000.00 ($3,000,000.00 (Eleven Million dollars only)"
    } else{
        document.getElementById("Motor4").innerHTML = "Need for speed"
    }
}