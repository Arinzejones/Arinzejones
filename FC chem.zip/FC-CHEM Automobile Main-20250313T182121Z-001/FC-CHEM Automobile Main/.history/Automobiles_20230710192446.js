if(document.getElementById("Motor").innerHTML === "1. Ofada Rice and Stew"){
    document.getElementById("Motor").innerHTML = "N2,400.00 (Two thousand, Four hundred Naira only)";
} else {
    document.getElementById("Motor").innerHTML = "1. Ofada Rice and Stew"};
}