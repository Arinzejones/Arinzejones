

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."};
}

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."};
}

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."};
}