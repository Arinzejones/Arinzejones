if(document.getElementById("Motor").innerHTML === "images/img1.png"){
    document.getElementById("Motor").innerHTML = "N3,000,000.00 (Three million Naira only)";
} else {
    document.getElementById("Motor").innerHTML = "images/img1.png"};

    function rice(){
        if(document.getElementById("Motor").innerHTML === "images/img1.png"){
            document.getElementById("Motor").innerHTML = "N3,000,000.00 (Three million Naira only)";
        } else {
            document.getElementById("").innerHTML = "images/img1.png"};
    }
    