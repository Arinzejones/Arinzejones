function price(){
    if(document.getElementById("Motor").innerHTML === "Affordable prices"){
        document.getElementById("Motor").innerHTML = "N3,000,000.00 (Three million Naira only)"
    } else {
        document.getElementById("Motor").innerHTML = "Affordable prices"
    }
}

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."};
}

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."};
}

function soup(){
    if(document.getElementById("Nsala").innerHTML === "2. Ofe Nsala and Yellow Eba."){
        document.getElementById("Nsala").innerHTML = "N3,500.00 (Three thousand, Five hundred Naira only)";
    } else{
        document.getElementById("Nsala").innerHTML = "2. Ofe Nsala and Yellow Eba."};
}