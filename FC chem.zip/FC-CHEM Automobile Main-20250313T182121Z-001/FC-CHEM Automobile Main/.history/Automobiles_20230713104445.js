function prices(){
        if(document.getElementById("Motor").innerHTML === "Affordable prices"){
            document.getElementById("Motor").innerHTML = "N3,000,000.00 (Three million Naira only)";
        } else {
            document.getElementById("Motor").innerHTML = "Affordable prices"};
    }
    